import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Test2 {
	public static void main(String[] args) throws SQLException {
		Connection connection=null;
		Statement statement=null;
		ResultSet resultset=null;
		
		String url="jdbc:mysql://localhost:3306/jdbc";
		String user="root";
		String password="password";
		
		
		try {
			connection= DriverManager.getConnection(url,user,password);
			if(connection!=null) {
				System.out.println("Connection Established");
				statement=connection.createStatement();
				if(statement!=null) {
					String query="select * from userinfo";
					resultset=statement.executeQuery(query);
					System.out.println("Id\t\tFirstName\t\tLastName");
					while(resultset.next()) {
						Integer id=resultset.getInt(1);
						String firstName=resultset.getString(2);
						String lastName=resultset.getString(3);
						System.out.println(id+"\t\t"+firstName+"\t\t"+lastName);
					}
				}
			}
			else System.out.println("Unable to Connect");
		} catch (SQLException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}
}
