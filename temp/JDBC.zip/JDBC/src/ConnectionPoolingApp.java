import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.MysqlConnectionPoolDataSource;


public class ConnectionPoolingApp {
public static void main(String[] args) throws SQLException {
	MysqlConnectionPoolDataSource connectionPool=new MysqlConnectionPoolDataSource();
	connectionPool.setURL("jdbc:mysql://localhost:3306/jdbc");
	connectionPool.setUser("root");
	connectionPool.setPassword("password");
	
	Connection connection=connectionPool.getConnection();
	Statement statement=null;
	ResultSet resultset=null;
	
	if(connection!=null) {
		System.out.println("Connection Established");
		statement=connection.createStatement();
		if(statement!=null) {
			String query="select * from userinfo";
			resultset=statement.executeQuery(query);
			System.out.println("Id\t\tFirstName\t\tLastName");
			while(resultset.next()) {
				Integer id=resultset.getInt(1);
				String firstName=resultset.getString(2);
				String lastName=resultset.getString(3);
				System.out.println(id+"\t\t"+firstName+"\t\t"+lastName);
			}
		}
	}
}
}
