import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.io.IOUtils;




public class BlobOpeartion {
	static Connection connection=null;
	static PreparedStatement statement=null;
	static ResultSet resultSet=null;

	public static void main(String[] args) throws Exception {
		String url="jdbc:mysql://localhost:3306/jdbc";
		String user="root";
		String password="password";
		
		
		try {
			connection= DriverManager.getConnection(url,user,password);
			if(connection!=null) {
				System.out.println("Connection Established");
				String query="insert into table (`name`,`image`) values(?,?)";
				statement=connection.prepareStatement(query);
				if(statement!=null) {
					statement.setString(1, "name");
					File f=new File("abc.jpg");
					FileInputStream fis=new FileInputStream(f);
					statement.setBlob(2, fis);
					int result=statement.executeUpdate();
					
					}
				}
			else System.out.println("Unable to Connect");
		}catch (SQLException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}
	static void retrival() throws Exception {
		String query="select * from table where name=?";
		statement=connection.prepareStatement(query);
		
		if(statement!=null) {
			statement.setString(1, "name");
			resultSet=statement.executeQuery();
			if(resultSet!=null) {
				if(resultSet.next()) {
					String name=resultSet.getString(1);
					InputStream is=  resultSet.getBinaryStream(2);
					FileOutputStream fos=new FileOutputStream("abc_download.jpg");
					/*
					 * byte []buffer=new byte[2048]; while(is.read(buffer)>0) { fos.write(buffer); }
					 * fos.flush();
					 */
					IOUtils.copy(is, fos);
					fos.close();
				}
			}
			
			
	}
	}

}
