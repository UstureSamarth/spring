import java.sql.SQLException;

import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;

public class RowSetApp {
	public static void main(String[] args) throws SQLException {
		
		RowSetFactory factory=RowSetProvider.newFactory();
		JdbcRowSet rowSet=factory.createJdbcRowSet();
		rowSet.setUrl("jdbc:mysql://localhost:3306/jdbc");
		rowSet.setUsername("root");
		rowSet.setPassword("password");
		rowSet.setCommand("select * from accounts");
		rowSet.execute();
		while(rowSet.next()) {
			System.out.println(rowSet.getString(1)+" "+rowSet.getInt(2));
		}
		System.out.println("Backward");
		while(rowSet.previous()) {
			System.out.println(rowSet.getString(1)+" "+rowSet.getInt(2));
		}
		
		/*
		 * rowSet.moveToInsertRow(); rowSet.setString(1, "Virat"); rowSet.setInt(2,
		 * 5000); rowSet.insertRow();
		 */
		rowSet.absolute(2);
		System.out.println(rowSet.getString(1));
		
		
		
	}
}
