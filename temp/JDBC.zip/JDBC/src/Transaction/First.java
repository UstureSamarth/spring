package Transaction;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class First {
	public static void main(String[] args) throws SQLException, IOException {
		Connection connection=null;
		Statement statement=null;
		ResultSet resultset=null;
		
		FileInputStream fis=new FileInputStream("/home/sarvatra.in/samarth.usture/Downloads/eclipse-workspace/JDBC/src/properties/db.properties");
		Properties p=new Properties();
		p.load(fis);
		String url=p.getProperty("url");
		String user=p.getProperty("user");
		String password=p.getProperty("password");
		
		
		try {
			connection= DriverManager.getConnection(url,user,password);
			if(connection!=null) {
				System.out.println("Connection Established\n");
				statement=connection.createStatement();
				if(statement!=null) {
					String query="select name,balance from accounts";
					resultset=statement.executeQuery(query);
					System.out.println("Name\t\tBalance");
					while(resultset.next()) {
						String name=resultset.getString(1);
						Integer  balance=resultset.getInt(2);
						System.out.println(name+"\t\t"+balance);
					}
					System.out.println();
					System.out.println("After transaction");
					connection.setAutoCommit(false);
					statement.executeUpdate("update accounts set balance=balance-3000 where name='sachin'");
					statement.executeUpdate("update accounts set balance=balance+3000 where name='dhoni'");
					Scanner sc=new Scanner(System.in);
					String option=sc.next();
					if(option.equals("yes")) {
						connection.commit();
						System.out.println("Transaction Commited");
					}
					else {
						connection.rollback();
						System.out.println("Transaction rollbacked");
					}
					sc.close();
					
					resultset=statement.executeQuery(query);
					System.out.println("Name\t\tBalance");
					while(resultset.next()) {
						String name=resultset.getString(1);
						Integer  balance=resultset.getInt(2);
						System.out.println(name+"\t\t"+balance);
					}
					
				}
			}
			else System.out.println("Unable to Connect");
		} catch (SQLException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}
}
