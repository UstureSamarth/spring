import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Test3 {
	public static void main(String[] args) throws SQLException {
		Connection connection=null;
		Statement statement=null;
		
		String url=null;
		String user=null;
		String password=null;
		
		Scanner sc=new Scanner(System.in);
		int age=sc.nextInt();
		String name=sc.nextLine();
		
		try {
			connection= DriverManager.getConnection(url,user,password);
			if(connection!=null) {
				 statement=connection.createStatement();
				 if(statement!=null) {
					 String query=String.format("insert into table (`age`,`name`) values ('%d','%s')", age,name);
					 statement.executeUpdate(query);
					 
					 }
					
				 }
		}catch (Exception e) {
			// TODO: handle exception
		}
		finally {
			sc.close();
		}
	}
	
}
