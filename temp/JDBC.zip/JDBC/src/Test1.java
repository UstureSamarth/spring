import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.Driver;

public class Test1 {
	public static void main(String[] args) throws SQLException {

		Driver driver = new Driver();
		DriverManager.registerDriver(driver);
		System.out.println("Driver Registered");

		Connection connection = DriverManager.getConnection(null);
		Statement statement = connection.createStatement();
		ResultSet resultset = statement.executeQuery(null);
		while (resultset.next()) {
			resultset.getInt(1);
		}
		resultset.close();
		statement.close();
		connection.close();

	}
}

// loading and registering of jar is not necessary as class name is available in jar-metainf-services.it will loaded using Class.forName()
