import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;



public class StoredProcedure {
	public static void main(String[] args) throws SQLException {
		Connection connection=null;
		CallableStatement cstmt=null;
		
		String url="jdbc:mysql://localhost:3306/jdbc";
		String user="root";
		String password="password";
		
		
		try {
			connection= DriverManager.getConnection(url,user,password);
			if(connection!=null) {
				System.out.println("Connection Established");
				String storedProcedure="{call procedurename(?,?,?)}";
				cstmt=connection.prepareCall(storedProcedure);
				cstmt.setInt(1, 5);
				cstmt.registerOutParameter(2, Types.VARCHAR);
				cstmt.registerOutParameter(3, Types.VARCHAR);
				cstmt.execute();
				System.out.println(cstmt.getString(2));
				System.out.println(cstmt.getString(3));
			}
			else System.out.println("Unable to Connect");
		} catch (SQLException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			connection.close();
		}
	}
}
