enum Results{
	PASS,FAIL,NR;
	int marks;
	
	Results() {
		System.out.println("Constructor");
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}
}
enum Gender{
	MALE,FEMALE,OTHER;
}
public class Enum {

	public static void main(String[] args) {
		/*Results.PASS.setMarks(87);
		int marks=Results.PASS.getMarks();
		System.out.println(marks);
		Gender []gr=Gender.FEMALE.values();
		for(Gender gg:gr) {
			System.out.println(gg+" "+gg.ordinal());
		}*/
		Results r=Results.PASS;
		switch(r) {
		case PASS:
			System.out.println("Passed");
			break;
		default:
			break;
		}

	}

}
