package SerializationDeserialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Account implements Serializable {
	String name="Samarth";
	transient String password="Usture";
	transient int pin=7656;
	
	private void writeObject(ObjectOutputStream oos) throws Exception{
		oos.defaultWriteObject();
		String encryptPassword=1234+password;
		int encryptedPin=1234+pin;
		oos.writeObject(encryptPassword);
		oos.writeInt(encryptedPin);
	}
	private void readObject(ObjectInputStream ois) throws Exception{
		ois.defaultReadObject();
		String encryptPassword=(String)ois.readObject();
		int encryptedPin=(int)ois.readInt();
		password=encryptPassword.substring(4);
		pin=encryptedPin-1234;
	}
	@Override
	public String toString() {
		return "Account [name=" + name + ", password=" + password + ", pin=" + pin + "]";
	}
	
}
public class Demo3 {

	public static void main(String[] args) throws Exception {
		
Account a=new Account();
System.out.println("Serialization Started");
		
		FileOutputStream fos=new FileOutputStream("abc.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(a);
		oos.close();
		
		System.out.println("Serialization ended");
		
System.out.println("Derialization Started");
		
		FileInputStream fis=new FileInputStream("abc.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		
		a=(Account)ois.readObject();
		ois.close();
		System.out.println(a);
		System.out.println("Derialization ended");

	}

}
