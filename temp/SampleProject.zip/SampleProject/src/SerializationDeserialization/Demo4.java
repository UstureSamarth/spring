package SerializationDeserialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Animal implements Serializable{
	int i=10;
}
class Animal2{
	int i;
	Animal2(){
		this.i=10;
		System.out.println("Animal2 Constructor");
	}
}

class Dog3 extends Animal2 implements Serializable{
	int j=20;

	@Override
	public String toString() {
		return "Dog3 [j=" + j + ", i=" + i + "]";
	}
	
}

class Dog1 extends Animal{
	int j=20;

	@Override
	public String toString() {
		return "Dog1 [j=" + j + ", i=" + i + "]";
	}
	
}

public class Demo4 {
  public static void main(String[] args) throws Exception {
	
	  Dog1 d=new Dog1();
	  Dog3 d2=new Dog3();
	  d2.i=888;
	  d2.j=999;
	  FileOutputStream fos=new FileOutputStream("abc.ser");
	  ObjectOutputStream oos=new ObjectOutputStream(fos);
	  oos.writeObject(d);
	  oos.writeObject(d2);
	  oos.close();
	  
	  FileInputStream fis=new FileInputStream("abc.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		//sequence of serialization and deserialization should be same.
		d=(Dog1)ois.readObject();
		d2=(Dog3)ois.readObject();
		System.out.println(d+"\n"+d2);
		ois.close();
		
 }
}
