package SerializationDeserialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Dog implements Serializable{
	Cat c=new Cat();
	
}
class Cat implements Serializable {
	Rat r=new Rat();
}
class Rat implements Serializable{
	int i=10;
}
public class Demo2 {

	public static void main(String[] args) throws Exception {
		Dog d=new Dog();
		
	System.out.println("Serialization Started");
		
		FileOutputStream fos=new FileOutputStream("abc.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(d);
		oos.close();
		
		System.out.println("Serialization ended");
		
		System.out.println("Derialization Started");
		
		FileInputStream fis=new FileInputStream("abc.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		//sequence of serialization and deserialization should be same.
		d=(Dog)ois.readObject();
		
		ois.close();
		System.out.println(d.c.r.i);
		System.out.println("Derialization ended");
		

	}

}
