package SerializationDeserialization;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


class Sample implements Serializable{
	int i=10;
	int j=20;
	@Override
	public String toString() {
		return "Sample [i=" + i + ", j=" + j + "]";
	}
} 

class Sample2 implements Serializable{
	transient static int i=30;//no effect on static on transient as serializable not applicable to class Level
	transient  int  j=40;//will not participate in serialization
	transient final int k=50;//no effect on final
	@Override
	public String toString() {
		return "Sample2 [i="+i+"j=" + j + ", k=" + k + "]";
	}
	
	
} 
public class TestApp {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		Sample s1=new Sample();
		Sample2 s2=new Sample2();
		
		System.out.println("Serialization Started");
		
		FileOutputStream fos=new FileOutputStream("abc.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(s1);
		oos.writeObject(s2);
		oos.close();
		
		System.out.println("Serialization ended");
		
		System.out.println("Derialization Started");
		
		FileInputStream fis=new FileInputStream("abc.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		//sequence of serialization and deserialization should be same.
		s1=(Sample)ois.readObject();
		s2=(Sample2)ois.readObject();
		ois.close();
		System.out.println(s1+"\n"+s2);
		System.out.println("Derialization ended");

	}

}
