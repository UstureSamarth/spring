
public class StaticNested {
	int x=10;
	static int y=20;
	static class Nested{
		public void m1() {
			System.out.println("Instance method inside static method");
		}
		public static void m2() {
			System.out.println("Static method inside static method");
		}
		public static void main(String[] args) {
			System.out.println("Main in static class");
		}
		public void m4() {
//			System.out.println(x);
			System.out.println(y);
		}
	}
	public static void main(String[] args) {
		System.out.println("Main Method");
		StaticNested.Nested n=new StaticNested.Nested();
		n.m1();
		Nested.m2();
//		Nested.main(args);
	}

}
