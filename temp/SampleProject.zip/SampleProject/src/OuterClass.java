//$ means inner class
//without existance of outer class inner will not exist
class OuterClass//public,default,final,abstract,strictfp
{
	
	int x=10;
	static int y=20;
	int z=9;
	//both are accessible inside inner class
	
	class InnerClass//above all and private,static,protected
	{
		//inside inner static will not come
		/*public static void main(String[] args) {
			System.out.println("Inner");

		}*/
		int y=100;
		int z=99;
		public void m1() {
			int z=1000;
			System.out.println("Inside inner class instance method");
			System.out.println(x);
			System.out.println(y);
			System.out.println(z);
			System.out.println(this.z);
			System.out.println(OuterClass.this.z);
		}
	}
	
	public void m2() {
		InnerClass i=new InnerClass();
		i.m1();
	}

	public static void main(String[] args) {
		System.out.println("Outer");
		OuterClass o= new OuterClass();
		
		//OuterClass.InnerClass n=o.new InnerClass();
		//n.m1();
		
		new OuterClass().new InnerClass().m1();
		o.m2();

	}

}
