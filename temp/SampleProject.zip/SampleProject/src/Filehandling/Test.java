package Filehandling;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Test {

	public static void main(String[] args) throws IOException {
		File f=new File("/home/sarvatra.in/samarth.usture/Downloads/eclipse-workspace/SampleProject/src/Filehandling/info.txt");
		/*FileWriter fw=new FileWriter(f,true);
		fw.write(97);
		fw.write("\nSamarth\nUsture\n");
		char ch[]= {'a','b','c'};
		fw.write(ch);
		fw.flush();
		fw.close();*/
		
		//read character one by one
		FileReader fr=new FileReader(f);
		/*int i=fr.read();
		while(i!=-1) {
			System.out.print((char)i);
			i=fr.read();
		}
		*/
		char[] ch=new char[(int)f.length()];
		fr.read(ch);
		for(char c:ch) {
			System.out.print(c);
		}
		fr.close();
	}

}
