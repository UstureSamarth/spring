package Filehandling;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Test2 {

	public static void main(String[] args) throws IOException {
		File f=new File("/home/sarvatra.in/samarth.usture/Downloads/eclipse-workspace/SampleProject/src/Filehandling/info.txt");
		FileWriter fw=new FileWriter(f);
		BufferedWriter bw=new BufferedWriter(fw);
		bw.write(98);
		bw.write("Samarth");
		bw.newLine();
		bw.write("Usture");
		bw.newLine();
		char ch[]= {'a','b','c'};
		bw.write(ch);
		bw.newLine();
		bw.flush();
		bw.close();
		
		FileReader fr=new FileReader(f);
		BufferedReader br=new BufferedReader(fr);
		
		String data=br.readLine();
		while(data!=null) {
			System.out.println(data);
			data=br.readLine();
		}
		
		br.close();
	}

}
