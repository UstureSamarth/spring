package Filehandling;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Test3 {

	public static void main(String[] args) throws FileNotFoundException {
		
		PrintWriter out=new PrintWriter("cric.txt");
		out.println(10);
		out.println("Sachin");
		out.println(true);
		out.println('M');
		out.println(53.5);
		out.flush();
		out.close();
		
		
	}

}
