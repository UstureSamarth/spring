package Filehandling;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Test4 {
	
	static void t1() throws IOException {
		PrintWriter pw=new PrintWriter("file3.txt");

		BufferedReader br1=new BufferedReader(new FileReader("file1.txt"));
		String line=br1.readLine();
		while(line!=null) {
			pw.println(line);
			line=br1.readLine();
		}
		BufferedReader br2=new BufferedReader(new FileReader("file2.txt"));
		line=br2.readLine();
		while(line!=null) {
			pw.println(line);
			line=br2.readLine();
		}
		
		pw.flush();
		pw.close();
		br1.close();
		br2.close();
	}
	//copy one one line from both files
	static void t2() throws IOException {
		PrintWriter pw=new PrintWriter("file4.txt");

		BufferedReader br1=new BufferedReader(new FileReader("file1.txt"));
		BufferedReader br2=new BufferedReader(new FileReader("file2.txt"));
		String line1=br1.readLine();
		String line2=br2.readLine();
		while(line1!=null || line2!=null) {
			if(line1!=null)
				pw.println(line1);
			if(line2!=null)
				pw.println(line2);
			line1=br1.readLine();
			line2=br2.readLine();
		}
		
		pw.flush();
		pw.close();
		br1.close();
		br2.close();
	
	}
	
	static void t3() throws IOException{
		PrintWriter pw=new PrintWriter("output.txt");

		BufferedReader br1=new BufferedReader(new FileReader("input.txt"));
		BufferedReader br2;
		String line1=br1.readLine();
		while(line1!=null) {
		Boolean isAvailable=false;
		br2=new BufferedReader(new FileReader("delete.txt"));
		String line2=br2.readLine();
			while(line2!=null) {
				if(line2.equals(line1)) {
					isAvailable=true;
					break;
				}
				line2=br2.readLine();
			}
			if(!isAvailable) {
				pw.println(line1);
				pw.flush();
			}
				
			line1=br1.readLine();
			br2.close();
		}
		
		
		pw.close();
		br1.close();
		
	}
	static void t4() throws IOException {
		PrintWriter pw=new PrintWriter("unique.txt");
		BufferedReader br1=new BufferedReader(new FileReader("duplicate.txt"));
		String line1=br1.readLine();
		BufferedReader br2;
		while(line1!=null) {
			Boolean isAvailable=false;
			br2=new BufferedReader(new FileReader("unique.txt"));
			String line2=br2.readLine();
			while(line2!=null) {
				if(line2.equals(line1))
				{
					isAvailable=true;
					break;
				}
				 line2=br2.readLine();
			}
			if(!isAvailable) {
				pw.println(line1);
				pw.flush();
			}
			 line1=br1.readLine();
		}
		pw.close();
		br1.close();
		
	}

	public static void main(String[] args) throws IOException {
//		t1();
//		t2();
//		t3();
		t4();
	}
		

}
