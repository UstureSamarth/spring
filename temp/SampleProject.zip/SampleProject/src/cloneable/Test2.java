package cloneable;


class Singleton{
	private static Singleton s=null;
	private Singleton() {
		
	}
	public static Singleton  getSingleton() {
		if(s==null) 
			s=new Singleton();
		return s;
			
	}
	
}
class Doubleton{
	private static Doubleton d1=null;
	private static Doubleton d2=null;
	private Doubleton() {
		
	}
	public static Doubleton  getDoubleton() {
		if(d1==null) {
			d1=new Doubleton();
			return d1;
		}else if(d2==null) {
			d2=new Doubleton();
			return d2;
		}else {
			if(Math.random()<0.5)
				return d1;
			return d2;
		}
			
	}
	
}
public class Test2 {
	public static void main(String[] args) {
		//static factory methods
		Runtime r1=Runtime.getRuntime();
		Runtime r2=Runtime.getRuntime();
		System.out.println(r1==r2);
		Singleton s1=Singleton.getSingleton();
		Singleton s2=Singleton.getSingleton();
		System.out.println(s1==s2);
		
		Doubleton d1=Doubleton.getDoubleton();
		Doubleton d2=Doubleton.getDoubleton();
		Doubleton d3=Doubleton.getDoubleton();
		Doubleton d4=Doubleton.getDoubleton();
		
		System.out.println(d1.hashCode());
		System.out.println(d2.hashCode());
		System.out.println(d3.hashCode());
		System.out.println(d4.hashCode());
	}
}
