package cloneable;

class Student{
	static {
		System.out.println("Student class Loading");
	}
	public Student() {
		System.out.println("Student object created");
	}
}

public class RuntimeClassNameAndObjectCreation {
	public static void main(String[] args) throws Exception {
		Student s=(Student)(Class.forName(args[0]).newInstance());
		
	}
}
