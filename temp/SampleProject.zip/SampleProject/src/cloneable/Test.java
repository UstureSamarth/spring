package cloneable;

class Cat {
	int j;
	Cat(int j){
		this.j=j;
	}
	@Override
	public String toString() {
		return "Cat [j=" + j + "]";
	}
	
}
class Dog implements Cloneable{
	Cat c;
	int i;
	public Dog (Cat c, int i) {
		super();
		this.c = c;
		this.i = i;
	}
	@Override
	protected Object clone() throws CloneNotSupportedException {
		//by default it is shallow cloning it will do below
      //	     return super.clone();
		//for deepcopy
		Cat c1=new Cat(c.j);
		Dog d=new Dog(c1, i);
		return d;
	}
	@Override
	public String toString() {
		return "Dog [c=" + c + ", i=" + i + "]";
	}
	
	
}
public class Test  implements Cloneable{
	 int i=10;
	 int j=20;
	 
		@Override
	public String toString() {
		return "Test [i=" + i + ", j=" + j + "]";
	}

		public static void main(String[] args) throws CloneNotSupportedException {
			
			/*
			 * Test t1=new Test(); Test t2=(Test)t1.clone(); t2.i=12; t2.j=22;
			 * System.out.println(t1); System.out.println(t2);
			 */
			 
			
			  Cat c=new Cat(10);
			  Dog d=new Dog(c, 20);
			  Dog d1=(Dog)d.clone();
			  d1.c.j=100;
			  d1.i=200;
			  System.out.println(d);
			  System.out.println(d1);
			 // as cat is not clonable its variable will not participate in cloning
			  //it is shallow cloning
			
		}
}
