//joda api
import java.time.*;
import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		
		/*LocalDate d=LocalDate.now();
		System.out.println(d);
		
		int dd=d.getDayOfMonth();
		int mm=d.getMonthValue();
		int yy=d.getYear();
		
		System.out.println(dd+" "+mm+" "+yy);
		
		LocalTime t=LocalTime.now();
		System.out.println(t);
		
		LocalDateTime dt=LocalDateTime.now();
		System.out.println(dt);
		
		LocalDateTime dt1=LocalDateTime.of(2002,2,19,12,45);
		System.out.println(dt1);
		System.out.println(dt1.plusMonths(2));
		
		ZoneId zone=ZoneId.systemDefault();
		System.out.println(zone);
		ZonedDateTime z=ZonedDateTime.now(zone);
		System.out.println(z);
		
		LocalDate today=LocalDate.now();
		LocalDate dob=LocalDate.of(2002,2,19);
		Period p=Period.between(today, dob);
		System.out.println(p);
		System.out.println("Age is "+p.getYears()+" years "+p.getMonths()+" months "+p.getDays()+" days ");
*/
		Scanner sc=new Scanner(System.in);
		Integer year=sc.nextInt();
		Year y=Year.of(year);
		System.out.println(y.isLeap());
		sc.close();
		
		
	}

}
