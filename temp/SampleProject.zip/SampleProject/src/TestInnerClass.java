
class Outer{
	class Inner{
		void m1() {
			System.out.println("Inside Inner");
		}
	}
}

public class TestInnerClass {

	public static void main(String[] args) {
		new Outer().new Inner().m1();

	}

}
