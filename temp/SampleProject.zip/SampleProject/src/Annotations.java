//adding metadata
//compiler consider during compile time

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)// on which to use
@Retention(RetentionPolicy.RUNTIME)//where to use
@interface CricketPlayer
{
	//these are not methods
	String gameName() default "Cricket";
	int runs() default 20000;
}

@CricketPlayer
class Virat{
	String name;
	int age;
	void disp() {
		System.out.println("VK18");
	}
}

public class Annotations {

	public static void main(String[] args) {
		Virat v=new Virat();
		v.disp();
		Class c=v.getClass();
		Annotation []a=c.getAnnotations();
		for(Object obj:a) {
			System.out.println(obj);
		}
		Annotation at=c.getAnnotation(CricketPlayer.class);
		CricketPlayer cp=(CricketPlayer)at;
		System.out.println(cp.gameName());
		System.out.println(cp.runs());
	}

}
