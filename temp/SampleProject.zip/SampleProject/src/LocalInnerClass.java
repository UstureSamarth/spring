
public class LocalInnerClass {
	int x=10;
	static int y=20;
	public  void m1() {
		class In{
			public void add(int a,int b) {
				System.out.println(a+b);
			}
			public void m2() {
				System.out.println(x);
				System.out.println(y);
			}
		}
		new In().add(6,7);
		new In().add(9,7);
		new In().m2();
	}

	public static void main(String[] args) {
		new LocalInnerClass().m1();
	}

}
